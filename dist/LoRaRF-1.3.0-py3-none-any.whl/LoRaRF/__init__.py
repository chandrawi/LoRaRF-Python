# __init__.py
from .SX126x import SX126x
